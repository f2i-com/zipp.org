# ZIPP 0.0.33 starter

A web page that runs a program in a ZIPP sandbox, with no build step and no
dependencies. It needs two files from the [ZIPP 0.0.33 release](https://github.com/f2i-com/zipp.org/releases/tag/v0.0.33)
beside it, which this folder does not include:

- `zipp.mjs`, the loader, from `zipp-0.0.33-wasm-embed-kit.zip`;
- `zipp-0.0.33-javascript.wasm`, the JavaScript engine (4.85 MB; 1.25 MB as `.wasm.br`).

## 1. Download the two files

In this folder, on macOS or Linux:

```sh
curl -fLO https://github.com/f2i-com/zipp.org/releases/download/v0.0.33/zipp-0.0.33-wasm-embed-kit.zip
unzip -j zipp-0.0.33-wasm-embed-kit.zip zipp-0.0.33-wasm-embed-kit/zipp.mjs
curl -fLO https://github.com/f2i-com/zipp.org/releases/download/v0.0.33/zipp-0.0.33-javascript.wasm
```

On Windows 10 or later, in PowerShell or Command Prompt (`curl.exe` and
`tar` come with Windows; in PowerShell, `curl` alone is another command):

```powershell
curl.exe -fLO https://github.com/f2i-com/zipp.org/releases/download/v0.0.33/zipp-0.0.33-wasm-embed-kit.zip
tar -xf zipp-0.0.33-wasm-embed-kit.zip --strip-components=1 zipp-0.0.33-wasm-embed-kit/zipp.mjs
curl.exe -fLO https://github.com/f2i-com/zipp.org/releases/download/v0.0.33/zipp-0.0.33-javascript.wasm
```

The folder then holds `index.html`, `main.mjs`, `zipp.mjs` and
`zipp-0.0.33-javascript.wasm`; the kit's `.zip` can go. The release's
[`SHA256SUMS`](https://github.com/f2i-com/zipp.org/releases/download/v0.0.33/SHA256SUMS) lists both downloads' checksums.

## 2. Serve the folder

Browsers do not run this page from a `file://` address. Serve the folder
over HTTP with either of these, and open the address it prints:

```sh
python3 -m http.server 8000     # then open http://localhost:8000/ (Windows: py -m http.server 8000)
npx serve .                     # then open http://localhost:3000/
```

## 3. What you should see

The page, and the browser's console, show what the program printed:

```text
6 * 7 = 42
fetch is undefined
```

`fetch` is undefined because the sandbox was given no network permission.
If `zipp.mjs` or the engine is missing, or the page was opened as a file,
the page says which.

## Content-Security-Policy

`index.html` sets a policy with what ZIPP needs, and a page of yours that
sends one must allow the same: `zipp.mjs` imports the engine's bindings from a
`blob:` URL and starts each sandbox's Worker from itself.

```text
script-src 'self' blob: 'wasm-unsafe-eval'; worker-src 'self' blob:
```

## A smaller download: `.wasm.br`

The release also has `zipp-0.0.33-javascript.wasm.br`: the same engine compressed with
Brotli, about a quarter of the size (1,253,579 bytes against
4,854,369). Serve it with `Content-Encoding: br` and
`Content-Type: application/wasm` and the browser decodes it; `zipp.mjs` 1.2.0,
in the kit as published now, also loads a `.wasm.br` URL itself, decompressing
it where the runtime can (Node, Firefox) or falling back to the plain `.wasm`
beside it. Simple servers such as `python3 -m http.server` send no
`Content-Encoding`, so this starter loads the plain `.wasm`.

## Other engines

Each is one file from the same release; change `ENGINE` in `main.mjs`.

- `zipp-0.0.33-javascript-lite.wasm` (2.83 MB; 0.78 MB as `.wasm.br`): JavaScript without `Intl` and `Temporal`.
- `zipp-0.0.33-javascript-python.wasm` (8.62 MB; 2.02 MB as `.wasm.br`): JavaScript and Python, torch built in.
  For Python, also create the sandbox with `{ language: "python" }` and give it
  a Python program, such as `print("6 * 7 =", 6 * 7)`.
- `zipp-0.0.33-javascript-python-base.wasm` (6.58 MB) with `zipp-0.0.33-torch-package.wasm`
  (2.16 MB): Python without torch, adding torch only when a program
  needs it: `loadZipp({ engine: "./zipp-0.0.33-javascript-python-base.wasm", packages: ["./zipp-0.0.33-torch-package.wasm"] })`.

## Next

- Permissions (storage, files, a network allowlist, host functions) and
  limits: https://www.zipp.org/wasm/#from-0-0-26
- Switch each one on and off in your browser: https://www.zipp.org/sandbox/playground/
- The kit's own `README.md` covers `zipp.mjs` in full, Node, Deno and Bun.
