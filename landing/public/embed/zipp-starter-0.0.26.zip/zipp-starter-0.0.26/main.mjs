// ZIPP 0.0.26 starter: run a program in a sandbox that permits nothing.
//
// Put zipp.mjs (from zipp-0.0.26-wasm-embed-kit.zip) and zipp-0.0.26-javascript.wasm beside this file,
// serve the folder over HTTP and open it; README.md has the commands.

const ENGINE = "./zipp-0.0.26-javascript.wasm";

const status = document.getElementById("status");
const output = document.getElementById("output");
const show = (state, text) => {
  status.dataset.state = state;
  status.textContent = text;
};

async function main() {
  if (location.protocol === "file:") {
    throw new Error("Open this page through a web server, not as a file: run `python3 -m http.server 8000` in this folder and visit http://localhost:8000/ (README.md).");
  }

  // A dynamic import, so that a missing zipp.mjs is reported on the page.
  show("loading", "Loading zipp.mjs…");
  let loadZipp;
  try {
    ({ loadZipp } = await import("./zipp.mjs"));
  } catch (error) {
    throw new Error(`zipp.mjs did not load (${error.message}). Download it from the embed kit: README.md has the command.`);
  }

  show("loading", `Loading ${ENGINE.slice(2)}…`);
  let zipp;
  try {
    zipp = await loadZipp(new URL(ENGINE, import.meta.url));
  } catch (error) {
    throw new Error(`The engine did not load (${error.message}). Download ${ENGINE.slice(2)}: README.md has the command.`);
  }

  // Nothing is permitted: no storage, files, network or host functions.
  // It runs in its own Worker, stopped after 30 s or 50 million steps.
  show("running", "Running the program in a sandbox…");
  const sandbox = await zipp.createSandbox();
  try {
    const { output: lines } = await sandbox.run(`
  console.log("6 * 7 =", 6 * 7);
  console.log("fetch is", typeof fetch);
`);
    output.textContent = lines.join("\n");
    console.log(lines.join("\n"));
  } finally {
    await sandbox.close();
  }
  show("done", `Done: ZIPP ${zipp.meta.version}, the ${zipp.meta.variant} engine.`);
}

main().catch((error) => {
  // A ZippSandboxError also says why the sandbox stopped (error.category).
  const why = error.category ? ` (${error.category})` : "";
  show("error", `${error.message}${why}`);
  console.error(error);
});
